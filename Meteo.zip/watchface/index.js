﻿
	/********************************
	*								*
	*			Meteo	v0.2		*
	*		2024 © leXxiR [4pda]	*
	*								*
	*********************************/
	   
    try {
    (() => {
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;


		const wfv = 'v0.1'			// версия циферблата (для сброса настроек)
        
        const { width: DEVICE_WIDTH, height: DEVICE_HEIGHT } = hmSetting.getDeviceInfo();
		const radius = DEVICE_WIDTH / 2, centerX = DEVICE_WIDTH / 2, centerY = DEVICE_HEIGHT / 2
		const koeff = DEVICE_WIDTH / 466;		// коэффициент масштабирования

		let isAOD = hmSetting.getScreenType() == hmSetting.screen_type.AOD;

		let lang = hmSetting.getLanguage() == 4 ? 0 : 1
		let mileageUnit = hmSetting.getMileageUnit();	// 0 	metric (СИ)			1 	imperial
		let timeFormat = hmSetting.getTimeFormat();		// 0 	12					1	24

		const curTime = hmSensor.createSensor(hmSensor.id.TIME);
		const battery = hmSensor.createSensor(hmSensor.id.BATTERY);
		
		const step = hmSensor.createSensor(hmSensor.id.STEP);
		const heart = hmSensor.createSensor(hmSensor.id.HEART);
		const calorie = hmSensor.createSensor(hmSensor.id.CALORIE);

		const distance = hmSensor.createSensor(hmSensor.id.DISTANCE);
		const stand = hmSensor.createSensor(hmSensor.id.STAND)
		const pai = hmSensor.createSensor(hmSensor.id.PAI);
		const fatburn = hmSensor.createSensor(hmSensor.id.FAT_BURRING);
		const spo2 = hmSensor.createSensor(hmSensor.id.SPO2);
		const stress = hmSensor.createSensor(hmSensor.id.STRESS);

		//const weather = hmSensor.createSensor(hmSensor.id.WEATHER);
		//let weather_icons = Array.from(Array(29), (v, k) => `w_${k}.png`)

		let battText, battScale
		let dateText, dayNameText = [], dayTemp = [], dayWeatherIcon = []
		const daysNum = 5
		let hourText, minText
		
		let curTempText, curWeatherIcon, curCityName, curHumText, curWindText, curWindPointer, updateTimeText
		const speedUnit = [	
							[' м/с', ' m/s'],		//0
							]

		const colors = [0xfc3026, 0xfc9126, 0xfcea26, 0xe5fc26, 0x95fc26, 0x26fc67, 0x26fcf9, 0x26c7fc, 0x9f26fc, 0xfc26d6, 0xfc265d];
		const defColors = [5];
		let cIndex = defColors		// индексы цветов: основной 
		const cIndexName = [	
							['Основной цвет', 'Main color'],
							]

		let pulseText, pulseValueText
		let line

		let actValueText, actScale
		let actIndex = 0, selectedIndex = 0, lastSelectedIndex = selectedIndex
		let actIcon
		
		const activities = [
							['ШАГИ', 'STEPS'], 								// 0
							['РАССТОЯНИЕ', 'DISTANCE'],  					// 1
							['ПУЛЬС', 'HEART'],		  						// 2
							['КАЛОРИИ', 'CALORIES'],  						// 3
							['КАРДИО', 'FAT BURNING'], 						// 4
							['РАЗМИНКА', 'STAND'],  						// 5
							['PAI', 'PAI'], 		 						// 6
							['КИСЛОРОД', 'OXYGEN'], 						// 7
						];
		
		const actNum = activities.length;

		let copyright = ''



		let degreeSum = 0
		const crownSensitivity = 70		// уровень чувствительности колесика

	
		// функция функция мастшабирования значений в зависимости от размера экрана
		function sc(v) {
			return v * koeff
		}

        function getLangIndex() {
			lang = hmSetting.getLanguage() == 4 ? 0 : 1
			//lang = 0
        }


		// класс текст с обводкой
		class TextWithOutline {      
		  constructor(props) {
			this._x = props.x || 0;
			this._y = props.y || 0;
			this._widget = [];
			this._color = (props.color == null) ? 0xffffff : props.color;
			this._color_outline = (props.color_outline == null) ? 0x000000 : props.color_outline;
			this._offset = props.offset || 2;
			this._group = props.group || hmUI;

			for (let i = 0; i < 5; i++) {
				this._widget[i] = this._group.createWidget(hmUI.widget.TEXT, {
					x: this._x,
					y: this._y,
					w: props.w || 100,
					h: props.h || 40,
					text_size: props.text_size || 30,
					char_space: props.char_space || 0,
					line_space: props.line_space || 0,
					text: props.text,
					color: i > 3 ? this._color : this._color_outline,
					align_h: props.align_h || hmUI.align.CENTER_H,
					align_v: props.align_v || hmUI.align.CENTER_V,
					text_style: props.text_style || hmUI.text_style.NONE,
				});

				if (props.font){
					this._widget[i].setProperty(hmUI.prop.MORE, {
						font: props.font
					});
				}
			}

			this._widget[0].setProperty(hmUI.prop.MORE, {
				x: this._x - this._offset,
				y: this._y + this._offset
			});
			this._widget[1].setProperty(hmUI.prop.MORE, {
				x: this._x + this._offset,
				y: this._y - this._offset
			});
			this._widget[2].setProperty(hmUI.prop.MORE, {
				x: this._x - this._offset,
				y: this._y - this._offset
			});
			this._widget[3].setProperty(hmUI.prop.MORE, {
				x: this._x + this._offset,
				y: this._y + this._offset
			});
		  }
		
		  hide() {
			this._widget.forEach(item => {
			  item.setProperty(hmUI.prop.VISIBLE, false);
			});
		  }

		  show() {
			this._widget.forEach(item => {
			  item.setProperty(hmUI.prop.VISIBLE, true);
			});
		  }

		  set visible(v) {
			if (v) this.show()
			else  this.hide();
		  }
		  
		  set x(v) {
			this._x = v;
			this._widget[4].setProperty(hmUI.prop.MORE, {x: this._x});
			this._widget[0].setProperty(hmUI.prop.MORE, {x: this._x - this._offset});
			this._widget[1].setProperty(hmUI.prop.MORE, {x: this._x + this._offset});
			this._widget[2].setProperty(hmUI.prop.MORE, {x: this._x - this._offset});
			this._widget[3].setProperty(hmUI.prop.MORE, {x: this._x + this._offset});
		  }

		  set y(v) {
			this._y = v;
			this._widget[4].setProperty(hmUI.prop.MORE, {y: this._y});
			this._widget[0].setProperty(hmUI.prop.MORE, {y: this._y + this._offset});
			this._widget[1].setProperty(hmUI.prop.MORE, {y: this._y - this._offset});
			this._widget[2].setProperty(hmUI.prop.MORE, {y: this._y - this._offset});
			this._widget[3].setProperty(hmUI.prop.MORE, {y: this._y + this._offset});
		  }

		  set text(txt) {
			this._widget.forEach(item => {
			  item.setProperty(hmUI.prop.TEXT, txt);
			});
		  }
		  
		  set color(v) {
			this._color = v;
			this._widget[4].setProperty(hmUI.prop.MORE, {color: this._color});
		  }

		  set color_outline(v) {
			this._color_outline = v;
			for (let i = 0; i < 4; i++) {
				this._widget[i].setProperty(hmUI.prop.MORE, {color: this._color_outline});
			}
		  }		  
		}
	
		// класс текст с тенью
		class TextWithShadow {      
		  constructor(props) {
			this._x = props.x || 0;
			this._y = props.y || 0;
			this._offset = props.offset || 2;
			this._group = props.group || hmUI;
			
			this._shadow = this._group.createWidget(hmUI.widget.TEXT, {
				x: this._x + this._offset,
				y: this._y + this._offset,
				w: props.w || 100,
				h: props.h || 100,
				text_size: props.text_size || 30,
				char_space: props.char_space || 0,
				line_space: props.line_space || 0,
				text: props.text,
				color: (props.color_shadow == null) ? 0x000000 : props.color_shadow,
				align_h: props.align_h || hmUI.align.CENTER_H,
				align_v: props.align_v || hmUI.align.CENTER_V,
				text_style: props.text_style || hmUI.text_style.NONE,
			});

			this._widget = this._group.createWidget(hmUI.widget.TEXT, {
				x: this._x,
				y: this._y,
				w: props.w || 100,
				h: props.h || 40,
				text_size: props.text_size || 30,
				char_space: props.char_space || 0,
				line_space: props.line_space || 0,
				text: props.text,
				color: (props.color == null) ? 0xffffff : props.color,
				align_h: props.align_h || hmUI.align.CENTER_H,
				align_v: props.align_v || hmUI.align.CENTER_V,
				text_style: props.text_style || hmUI.text_style.NONE,
			});

			if (props.font){
				this._widget.setProperty(hmUI.prop.MORE, {
					font: props.font
				});
				this._shadow.setProperty(hmUI.prop.MORE, {
					font: props.font
				});
			}
		  }
		
		  hide() {
			this._widget.setProperty(hmUI.prop.VISIBLE, false);
			this._shadow.setProperty(hmUI.prop.VISIBLE, false);
		  }

		  show() {
			this._widget.setProperty(hmUI.prop.VISIBLE, true);
			this._shadow.setProperty(hmUI.prop.VISIBLE, true);
		  }

		  set visible(v) {
			if (v) this.show()
			else  this.hide();
		  }
		  
		  set x(v) {
			this._x = v;
			this._widget.setProperty(hmUI.prop.MORE, {x: this._x});
			this._shadow.setProperty(hmUI.prop.MORE, {x: this._x + this._offset});
		  }

		  set y(v) {
			this._y = v;
			this._widget.setProperty(hmUI.prop.MORE, {y: this._y});
			this._shadow.setProperty(hmUI.prop.MORE, {y: this._y + this._offset});
		  }

		  set text(txt) {
			this._widget.setProperty(hmUI.prop.TEXT, txt);
			this._shadow.setProperty(hmUI.prop.TEXT, txt);
		  }

		  set color(v) {
			this._widget.setProperty(hmUI.prop.MORE, {color: v});
		  }
		}	




//------------- батарея ------------------
		function updateBattery() {
			let val = battery.current;
			//battText.setProperty(hmUI.prop.TEXT, val + '%');
			battText.text = val + '%'; 
            battScale.setProperty(hmUI.prop.MORE, {
			  x: sc(190),
			  y: sc(17),
			  w: (DEVICE_WIDTH - 2 * sc(190)) * val / 100,
			  h: 10,
              color: 0xdedede,
			  radius: 3,
            });
		}

//------------- пульс ------------------
		function updatePulse() {
			let value = heart.last;	//getLast();
			if (value) value = value.toString()
			else  value = '--';
			pulseValueText.setProperty(hmUI.prop.TEXT, value);
		}

//------------- дата и день недели ------------------
		let lastDate = {date: 0, day: 0, month: 0}
		
		function updateDate() {
			if (curTime.day != lastDate.date){
				lastDate.date = curTime.day;
				dateText.setProperty(hmUI.prop.TEXT, curTime.day.toString().padStart(2, "0"));
			}

			if (curTime.week != lastDate.day){
				lastDate.day = curTime.week;
				let curDayNum = curTime.week - 1;
				for(let i = 0; i < daysNum; i++) {
					dayNameText[i].setProperty(hmUI.prop.MORE, {
					  text: day_names[curDayNum][lang],
					  font: 'fonts/DirectoBold.ttf',
					  color: curDayNum > 4 ? 0xdb0000: 0xdedede,
					});
					curDayNum = (curDayNum + 1) % 7;
				}				
				//dayNameText.text = getCurrentDayName();
			}
		}

		const day_names = [	
								["ПН", "Mon"],
								["ВТ", "Tue"],
								["СР", "Wed"],
								["ЧТ", "Thu"],
								["ПТ", "Fri"],
								["СБ", "Sat"],
								["ВС", "Sun"]
							];

		function getCurrentDayName() {
			return  day_names[curTime.week - 1][lang];
        }

		function getCurrentMonthName() {
			const month_names = [	
									["ЯНВ", "JAN"],
									["ФЕВ", "FEB"],
									["МАР", "MAR"],
									["АПР", "APR"],
									["МАЙ", "MAY"],
									["ИЮН", "JUN"],
									["ИЮЛ", "JUL"],
									["АВГ", "AUG"],
									["СЕН", "SEP"],
									["ОКТ", "OCT"],
									["НОЯ", "NOV"],
									["ДЕК", "DEC"],
								];
							
			return  month_names[curTime.month - 1][lang];
        }

		function getMonthName(index) {
			const month_names = [	
									["января", "Jan"],
									["февраля", "Feb"],
									["марта", "Mar"],
									["апреля", "Apr"],
									["мая", "May"],
									["июня", "Jun"],
									["июля", "Jul"],
									["августа", "Aug"],
									["сентября", "Sep"],
									["октября", "Oct"],
									["ноября", "Nov"],
									["декабря", "Dec"],
								];
							
			return  month_names[index][lang];
        }


//------------- время ------------------
		let lastTime = {hour: 0, min: 0}

        function updateTime() {
			let curHour = curTime.hour;
			let curMinute = curTime.minute;
			if (curHour != lastTime.hour){
				lastTime.hour = curHour;
				curHour = curHour.toString().padStart(2, "0");
				//hourText.setProperty(hmUI.prop.TEXT, curHour);
				hourText.text = curHour; 
			}
			if (curMinute != lastTime.min){
				lastTime.min = curMinute;
				curMinute = curMinute.toString().padStart(2, "0");
				//minText.setProperty(hmUI.prop.TEXT, curMinute);
				minText.text = curMinute;
			}
        }



		
		let secTimer = null

		function startSecTimer() {
			stopSecTimer();
			//setTimeout(() => {
				secTimer = setInterval(() => {
					//updateSec();
					updateTime();
				}, 1000);
			//}, 1000 - curTime.utc % 1000);
		}

		function stopSecTimer() {
			if (secTimer) clearInterval(secTimer);
			secTimer = null;
		}


		function setActualTime() {
			updateTime();
		}


//------------- обновить все данные ------------------
		function updateAllInfo() {
			updateTime();
			updateBattery();
			//updatePulse();
			//updateActivityScale();
			updateDate();
			updateActivityInfo(actIndex);
		}



//------------- форматированное время ------------------
		function getFormatTime(h, m) {
			let fH = h;
			let ampm = 'am';
			if (h == 0) fH = 12;
			else if (h >12) {
				fH = h - 12;
				ampm = 'pm';
			}
			
			return `${fH}:${m.toString().padStart(2, "0")}${ampm}`
		}


		function randomInt(...args) {
			let min = 0;
			let max = args[0];
			if (args.length > 1) {
				min = args[0];
				max = args[1];
			}
			let rand = min + Math.random() * (max + 1 - min);
			return Math.floor(rand);
		}


//------------- активности ------------------
		function getActivityValue(index){
			let value = 0;

			switch(index) {
			   case 0:
					value = step.current.toString();
				break;
			   case 1:
					mileageUnit = hmSetting.getMileageUnit();
					if (mileageUnit == 1){
						const distUnit = ['ми', 'mi']
						let curDist = (distance.current / 1609.34).toFixed(2);
						value = curDist.toString() + distUnit[lang];
					} else {
						const distUnit = [['м', 'км'], ['m', 'km']]
						let ind = 1;
						let curDist = distance.current;
						if (curDist < 1000) {
							ind = 0;
						} else {
							curDist = (curDist / 1000).toFixed(2);
						}
						value = curDist.toString() + distUnit[lang][ind];
					}
				break;
			   case 2:
					value = heart.last;	//getLast();
					if (value) value = value.toString()
					else  value = '--';
				break;
			   case 3:
					value = calorie.current.toString();
				break;
			   case 4:
					value = fatburn.current.toString();
					if (value < 100 && fatburn.target < 100) value = value.toString() + '/' + fatburn.target.toString();
					else value = value.toString();
				break;
			   case 5:
					value = stand.current.toString() + '/' + stand.target.toString();
				break;
			   case 6:
					value = pai.totalpai.toString();
				break;
			   case 7:
					value = spo2.current;		// getCurrent().value
					if (value) value = value.toString() + '%';
					else  value = '--';
				break;
			   default:
					value = '--';
				break;
			}

			return value
		}

		function getActivityProgress(index){
			let value = 0;

			switch(index) {
			   case 0:
			   case 1:
					//value = step.getCurrent() / step.getTarget();
					value = step.current / step.target;
				break;
			   case 2:
					//let userAge = getProfile().age;
					let userAge = hmSetting.getUserData().age;
					if (!userAge) userAge = 40;
					const maxBPM = 220 - userAge - 60; // 220 — ваш возраст - 60 (покой) 
					//value = heart.getLast() - 60;	// сдвигаем шкалу: покой (60) - будет 0
					value = heart.last - 60;		// сдвигаем шкалу: покой (60) - будет 0	
					if (value < 0 ) value = 0;
					value = value / maxBPM;
				break;
			   case 3:
					//value = calorie.getCurrent() / calorie.getTarget();
					value = calorie.current / calorie.target;
				break;
			   case 4:
					//value = fatburn.getCurrent() / fatburn.getTarget();
					value = fatburn.current / fatburn.target;
				break;
			   case 5:
					//value = stand.getCurrent() / stand.getTarget();
					value = stand.current / stand.target;
				break;
			   case 6:
					//value = pai.getTotal() / 100;
					value = pai.totalpai / 100;
				break;
			   case 7:
					//value = spo2.getCurrent().value / 100;
					value = spo2.current / 100;
				break;
			   default:
					value = 0;
				break;
			}

			if (value > 1) value = 1;				
			return value				// возвращаем значение от 0 до 1
		}


		function updateActivityInfo(index){
			//actValueText.setProperty(hmUI.prop.TEXT, getActivityValue(index));
			actValueText.text = getActivityValue(index); 
			//actText.setProperty(hmUI.prop.TEXT, activities[index][lang]);
			actIcon.setProperty(hmUI.prop.SRC, `ico_${index}.png`);
            actScale.setProperty(hmUI.prop.MORE, {
			  x: sc(160),
			  y: DEVICE_HEIGHT - 30,
			  w: (DEVICE_WIDTH - 2 * sc(160)) * getActivityProgress(index),
			  h: 10,
              color: 0xdedede,
			  radius: 3,
            });
		}


		function toggleActivity(step = 1) {							// переключаем активности по кругу
			lastSelectedIndex = selectedIndex;
			actIndex += step;
			actIndex = actIndex < 0 ? actNum + actIndex : actIndex % actNum;
			//if (curAODmode > 2) hmFS.SysProSetInt('infoMAX_actIndex', actIndex);
			updateActivityInfo(actIndex);
			vibro();
        }


		function showActivityScreen() {
			vibro();
			let url = 'activityAppScreen';
			
			switch(actIndex) {
			   case 2:
					url = 'heart_app_Screen';
				break;
			   case 3, 6:
					url = 'PAI_app_Screen';
				break;
			   case 7:
					url = 'spo_HomeScreen';
				break;
			   default:
					url = 'activityAppScreen';
				break;
			}
			
			hmApp.startApp({ url: url, native: true });
			//launchApp({ url: url, native: true });
		}

//------------- вибро ------------------
        const vibrate = hmSensor.createSensor(hmSensor.id.VIBRATE);
        let stopVibro_Timer = null;
		
		function vibro(scene = 25) {
			let stopDelay = 50;
			vibrate.stop();
			vibrate.scene = scene;
			if(scene < 23 || scene > 25) stopDelay = 1200;
			vibrate.start();
			stopVibro_Timer = timer.createTimer(stopDelay, 0, stopVibro, {});
        }		

		function stopVibro(){
			vibrate.stop();
			timer.stopTimer(stopVibro_Timer);
		}



//------------- коронка ------------------
		function onDigitalCrown() {
			try {
				hmApp.registerSpinEvent(function (key, degree) {
					degreeSum += degree;
					if (Math.abs(degreeSum) > crownSensitivity){
						let step = degreeSum < 0 ? -1 : 1;
						degreeSum = 0;
						/*
						if(userListScreen){
							if (Math.abs(degree) > 10) step *= 3;
							step *= listRowH;
							moveUserList(step);
						} else if(menuClosed){
						if(!colorPickerScreenClosed){
							step *= (btnSize + space);
							if (Math.abs(degree) > 10) step *= 3;
							moveColorPicker(step);
						} else if(menuClosed) */toggleActivity(step);
					}
				})
			} catch (e) {
				console.log('SpinEvent Error: ', e);
			}
		}

		function offDigitalCrown() {
			try {
				hmApp.unregisterSpinEvent();
			} catch (e) {
				console.log('SpinEvent Error: ', e);
			}
		}


// чтение погодных данных из файла
		const mini_app_id = 1065824;
		const file_name_weather = "weather.json";
		const file_name_forecast = "forecast.json";

		function arrayBufferToCyrillic(buffer) {
		  let result = '';
		  const bytes = new Uint8Array(buffer);

		  let i = 0;
		  while (i < bytes.length) {
			let byte1 = bytes[i++];
			
			// Обработка 1-байтовых символов (ASCII)
			if (byte1 < 0x80) {
			  result += String.fromCharCode(byte1);
			}
			// Обработка 2-байтовых символов (UTF-8 кодировка для кириллицы)
			else if (byte1 >= 0xC0 && byte1 < 0xE0) {
			  let byte2 = bytes[i++];
			  let charCode = ((byte1 & 0x1F) << 6) | (byte2 & 0x3F);
			  result += String.fromCharCode(charCode);
			}
			// Обработка 3-байтовых символов (например, для UTF-8)
			else if (byte1 >= 0xE0 && byte1 < 0xF0) {
			  let byte2 = bytes[i++];
			  let byte3 = bytes[i++];
			  let charCode = ((byte1 & 0x0F) << 12) | ((byte2 & 0x3F) << 6) | (byte3 & 0x3F);
			  result += String.fromCharCode(charCode);
			}
		  }

		  return result;
		}

		function read_weather_file(file_name) {
		  let str_result = "";
		  try {

			const [fs_stat, err] = hmFS.stat(file_name, {
			  appid: mini_app_id,
			});
			if (err == 0) {
			  console.log("--->size_alt:", fs_stat.size);

			  const fh = hmFS.open(file_name, hmFS.O_RDONLY, {
				appid: mini_app_id,
			  });

			  const len = fs_stat.size;
			  let array_buffer = new ArrayBuffer(len);
			  hmFS.read(fh, array_buffer, 0, len);
			  hmFS.close(fh);
			  str_result = arrayBufferToCyrillic(array_buffer);
			  console.log(`array_buffer = ${array_buffer}`);
			  console.log(`str_result = ${str_result}`);
			  return str_result;
			} else {
			  console.log("err:", err);
			}
		  } catch (error) {
			console.log("error:", error);
			console.log("FAIL: No access to hmFS.");
		  }
		  return "";
		}

	// обновление погоды
	
		const nightIcons = [1, 2]
		
		function updateWeather(weatherJson) {
		  console.log(`updateWeather()`);

		  let cityStr = "--";
		  let weatherIcon = 0;
		  let temperatureStr = "--";
		  let humidityStr = "--";
		  let windStr = "--";
		  let windDirection = 0;
		  //let pressureStr = "--";
		  let timeStr = "--:--";
		  
		  if (weatherJson != undefined && weatherJson != null) {
			console.log(`cityName = ${weatherJson.cityName}`);
			if (weatherJson.cityName != undefined && weatherJson.cityName != null && weatherJson.cityName.length > 0) {
			  cityStr = weatherJson.cityName;
			  cityStr = cityStr.replace(cityStr[0], cityStr[0].toUpperCase());
			}

			if (isFinite(weatherJson.weatherIcon)) {
			  weatherIcon = parseInt(weatherJson.weatherIcon);
			
				if(nightIcons.includes(weatherIcon)){
					let weather = hmSensor.createSensor(hmSensor.id.WEATHER);
					let weatherData = weather.getForecastWeather();
					const sunriseMins_def = 8 * 60;			// время восхода
					const sunsetMins_def = 20 * 60;			// и заката по умолчанию

					let sunData = weatherData.tideData;
					if (sunData.count > 0){
						today = sunData.data[0];
						sunriseMins = today.sunrise.hour * 60 + today.sunrise.minute;
						sunsetMins = today.sunset.hour * 60 + today.sunset.minute;
					} else {
						sunriseMins = sunriseMins_def;
						sunsetMins = sunsetMins_def;
					}

					let curMins = curTime.hour * 60 + curTime.minute;
					//let curMins = curTime.getHours() * 60 + curTime.getMinutes();
					let isDayNow = (curMins >= sunriseMins) && (curMins < sunsetMins);

					if (!isDayNow) weatherIcon += 'n';
				}
			}


			// console.log(`temperature = ${weatherJson.temperature}`);
			if (isFinite(weatherJson.temperature)) {
			  temperatureStr = Math.round(parseFloat(weatherJson.temperature)) + '°';
			  /*
			  if (isFinite(weatherJson.temperatureFeels)) {
				temperatureStr += '(' + weatherJson.temperatureFeels + '°)';
			  }*/
			}

			// console.log(`humidity = ${weatherJson.humidity}`);
			if (isFinite(weatherJson.humidity)) {
			  humidityStr = weatherJson.humidity + '%';
			}

			// console.log(`windSpeed = ${weatherJson.windSpeed}`);
			// console.log(`windGusts = ${weatherJson.windGusts}`);
			if (isFinite(weatherJson.windSpeed)) {
			  windStr = parseFloat(weatherJson.windSpeed);
			  windStr > 10 ? windStr = Math.round(windStr) : windStr = windStr.toFixed(1);
			  windStr += speedUnit[0][lang];
			}
			
			if (isFinite(weatherJson.windDirection)) {
			  windDirection = parseFloat(weatherJson.windDirection);
			}

			// console.log(`pressure = ${weatherJson.pressure}`);
			/*
			if (isFinite(weatherJson.pressure)) {
			  pressureStr = weatherJson.pressure + 'hPa';
			}
			*/
			
			if (isFinite(weatherJson.weatherTime)) {
			  const weatherTime = new Date(weatherJson.weatherTime);
			  // const dateNaw = new Date();
			  console.log(`weatherTime = ${weatherTime.toString()}`);
			  let hour = weatherTime.getHours().toString().padStart(2, "0");
			  let min = weatherTime.getMinutes().toString().padStart(2, "0");
			  timeStr = weatherTime.getDate() + ' ' + getMonthName(weatherTime.getMonth()) + ' ' + weatherTime.getFullYear() + '  ' + hour + ':' + min;
			}
		  }
		  
		  
		  curCityName.setProperty(hmUI.prop.TEXT, cityStr);
		  curTempText.setProperty(hmUI.prop.TEXT, temperatureStr);
		  curHumText.setProperty(hmUI.prop.TEXT, humidityStr);
		  curWindText.setProperty(hmUI.prop.TEXT, windStr);
		  // textPressure.setProperty(hmUI.prop.TEXT, pressureStr);

		  updateTimeText.setProperty(hmUI.prop.TEXT, timeStr);
		  
		  curWeatherIcon.setProperty(hmUI.prop.SRC, `w_${weatherIcon}.png`);
		  curWindPointer.setProperty(hmUI.prop.ANGLE, windDirection);
		}


// разница между датами в днях
		function getDaysBetweenDates(d0, d1) {
		  let diff = new Date(+d1).setHours(12) - new Date(+d0).setHours(12);	// устанавливаем время в каждой дате на 12
		  return Math.round(diff / 8.64e7);		// msPerDay = 8.64e7;
		}


	// обновление прогноза погоды по дням
		function updateForecast(forecastJson) {
		  console.log(`updateForecast()`);
		  let weatherIcon = 0;
		  let temperatureMaxStr = "--";
		  let temperatureMinStr = "--";

			let dayOffset = 0; 	// смещение дней для начала прогноза по дням
								// если прогноз был обновлен во ВТ, а сегодня СР, то dayOffset = 1
								// соотвественно для чтения данных будем использовать объект forecastJson.forecast[i + dayOffset]

			if (forecastJson != undefined && forecastJson != null) {
				if (isFinite(forecastJson.weatherTime)) {
					dayOffset = getDaysBetweenDates(forecastJson.weatherTime, Date.now());
				}
			}

			for(let i = 0; i < daysNum; i++) {
			  weatherIcon = 0;
			  temperatureMaxStr = "--";
			  temperatureMinStr = "--";
			  const ind = i + dayOffset;

			  if (forecastJson != undefined && forecastJson != null) {
				
				if (isFinite(forecastJson.forecast[ind].weatherIcon)) {
				  weatherIcon = parseInt(forecastJson.forecast[ind].weatherIcon);
				}

				if (isFinite(forecastJson.forecast[ind].temperatureMax)) {
				  temperatureMaxStr = Math.round(parseFloat(forecastJson.forecast[ind].temperatureMax)) + '°';
				}

				if (isFinite(forecastJson.forecast[ind].temperatureMin)) {
				  temperatureMinStr = Math.round(parseFloat(forecastJson.forecast[ind].temperatureMin)) + '°';
				}
			  }
			  
			  dayTemp[i].high.setProperty(hmUI.prop.TEXT, temperatureMaxStr);
			  dayTemp[i].low.setProperty(hmUI.prop.TEXT, temperatureMinStr);
		  
			  if (i) dayWeatherIcon[i].setProperty(hmUI.prop.SRC, `w_${weatherIcon}.png`);
			}

		}

		function updateWeatherData() {
			let weather_str = read_weather_file(file_name_weather);
			console.log(`weather_json = ${weather_str}`);
			let weather_json = JSON.parse(weather_str);

			updateWeather(weather_json);
			
			weather_str = read_weather_file(file_name_forecast);
			weather_json = JSON.parse(weather_str);

			updateForecast(weather_json);
		}



//--------------------------------------------------------------------------------------------

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                
            console.log('Watch_Face.ScreenNormal');

////////////////////////////////////////////////////////////////////
		// кэши шрифтов
			// время
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 120,
			  h: 105,
              text_size: 100,
              char_space: 0,
              line_space: 0,
              font: 'fonts/eras-demi-itc.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 /_-.,:;`'%°",
            });

			// название города
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 40,
              text_size: 28,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ kminaxg кминасрт АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ/_-.,:;`'%°",
            });

			// температура текущая
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 50,
              text_size: 44,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 /_-.,:;`'%°",
            });
			
			// влажность, скорость ветра
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ kminaxg кминасрт АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ/_-.,:;`'%°",
            });

			// время обновления 
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 30,
              text_size: 18,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ kminaxg кминасрт АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ/_-.,:;`'%°",
            });
			
			// дни недели
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 35,
              text_size: 26,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz  АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯабвгдеёжзийклмнопрстуфхцчшщъыьэюя/_-.,:;`'%°",
            });
			
			// дата
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 50,
              text_size: 46,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 /_-.,:;`'%°",
            });
			
			// активность
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 44,
              text_size: 36,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ kminaxg кминасрт АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ/_-.,:;`'%°",
            });

			// заряд батареи
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: DEVICE_WIDTH-2,
              y: DEVICE_HEIGHT-2,
              w: 315,
              h: 34,
              text_size: 30,
              char_space: 0,
              line_space: 0,
              font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 /_-.,:;`'%°",
            });
////////////////////////////////////////////////////////////////////          

			hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
			  w: DEVICE_WIDTH,
			  h: DEVICE_HEIGHT,
			  auto_scale: true,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

			copyright = hmUI.createWidget(hmUI.widget.TEXT, {
				x: DEVICE_WIDTH - 70,
				y: sc(40),
				w: 70,
				h: 30,
				text_size: 24,
				text: 'leXxiR',
				color: colors[cIndex[0]],
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V,
			});

			hmUI.createWidget(hmUI.widget.TEXT, {
				x: DEVICE_WIDTH - 59,
				y: sc(64),
				w: 70,
				h: 30,
				text_size: 24,
				text: '4pda',
				color: 0x4bd9da,
				align_h: hmUI.align.CENTER_H,
				align_v: hmUI.align.CENTER_V,
			});

	//----- время -----
			hourText = new TextWithOutline({
			  x: sc(60),
			  y: sc(58),
			  w: 120,
			  h: 105,
			  text_size: 100,
			  char_space: 0,
			  line_space: 0,
			  color: 0xffffff,
			  offset: 1,
			  text: '00',
			  font: 'fonts/eras-demi-itc.ttf',
			  align_h: hmUI.align.LEFT,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
			});

			minText = new TextWithOutline({
			  x:  sc(60),
			  y:  sc(140),
			  w: 120,
			  h: 105,
			  text_size: 100,
			  char_space: 0,
			  line_space: 0,
			  color: 0xc0c0c0,
			  offset: 1,
			  text: '00',
			  font: 'fonts/eras-demi-itc.ttf',
			  align_h: hmUI.align.LEFT,
			  align_v: hmUI.align.CENTER_V,
			  text_style: hmUI.text_style.NONE,
			});


	//----- погода -----
			curWeatherIcon = hmUI.createWidget(hmUI.widget.IMG, {
              x: sc(207),
              y: sc(107),
			  w: sc(100),
			  h: sc(100),
			  auto_scale: true,
              src: 'w_0.png',
            });

            curCityName = hmUI.createWidget(hmUI.widget.TEXT, {
              x: sc(207),
              y: sc(80),
              w: 200,
              h: 40,
              text_size: 28,
              char_space: 0,
              line_space: 0,
			  text: 'Пятигорск',
			  font: 'fonts/DirectoBold.ttf',
              color: 0xd0d0d0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });
			
            curTempText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: sc(320),
              y: sc(110),
              w: 90,
              h: 50,
              text_size: 44,
              char_space: 0,
              line_space: 0,
			  text: '26°',
			  font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

			hmUI.createWidget(hmUI.widget.IMG, {
              x: sc(323),
              y: sc(162),
              w: 17,
              h: 21,
			  src: 'ico_hum.png',
			});

            curHumText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: sc(350),
              y: sc(152),
              w: 80,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
			  text: '40%',
			  font: 'fonts/DirectoBold.ttf',
              color: 0xd0d0d0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

			curWindPointer = hmUI.createWidget(hmUI.widget.IMG, {
              x: sc(323-17/2),
              y: sc(187-21/2),
              w: 34,
              h: 42,
			  pos_x: 17/2,
			  pos_y: 21/2,
			  center_x: 17,
			  center_y: 21,
			  angle: 0,
			  src: 'ico_wind.png',
			});

            curWindText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: sc(350),
              y: sc(177),
              w: 110,
              h: 40,
              text_size: 24,
              char_space: 0,
              line_space: 0,
			  text: '3,2 м/с',
			  font: 'fonts/DirectoBold.ttf',
              color: 0xd0d0d0,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

            updateTimeText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: sc(207),
              y: sc(205),
              w: 220,
              h: 30,
              text_size: 18,
              char_space: 0,
              line_space: 0,
			  text: '20 октября 2024  21:39',
			  font: 'fonts/DirectoBold.ttf',
              color: 0xb6b6b6,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.NONE,
            });

	//----- дни -----
			for(let i = 0; i < daysNum; i++) {
				dayNameText[i] = hmUI.createWidget(hmUI.widget.TEXT, {
				  x: sc(25) + sc(84) * i,
				  y: centerY + 10,
				  w: 80,
				  h: 35,
				  text_size: 26,
				  char_space: 1,
				  line_space: 0,
				  text: '',
				  font: 'fonts/DirectoBold.ttf',
				  color: 0xffffff,
				  //color: 0xfff996,
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				  text_style: hmUI.text_style.NONE,
				});
				
				// дневная и ночная температуры
				let highTemp = hmUI.createWidget(hmUI.widget.TEXT, {
				  x: sc(25) + sc(84) * i,
				  y: sc(326),
				  w: 80,
				  h: 35,
				  text_size: 24,
				  char_space: 1,
				  line_space: 0,
				  text: '',
				  //text: `${24 - i*4}°`,
				  font: 'fonts/DirectoBold.ttf',
				  color: 0xf0f0f0,
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				  text_style: hmUI.text_style.NONE,
				});
				
				let lowTemp = hmUI.createWidget(hmUI.widget.TEXT, {
				  x: sc(25) + sc(84) * i,
				  y: sc(349),
				  w: 80,
				  h: 35,
				  text_size: 24,
				  char_space: 1,
				  line_space: 0,
				  text: '',
				  //text: `${12 - i*5}°`,
				  font: 'fonts/DirectoBold.ttf',
				  color: 0xb1b1b1,
				  align_h: hmUI.align.CENTER_H,
				  align_v: hmUI.align.CENTER_V,
				  text_style: hmUI.text_style.NONE,
				});
				
				dayTemp.push({ high: highTemp, low: lowTemp });
				
				if(i)
				dayWeatherIcon[i] = hmUI.createWidget(hmUI.widget.IMG, {
				  x: sc(38) + sc(84) * i,
				  y: sc(270),
				  w: sc(55),
				  h: sc(55),
				  auto_scale: true,
				  src: 'w_0.png',
				  //src: `w_${i}.png`,
				});
			}
	
	//----- дата -----
            dateText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: sc(25),
              y: centerY + 42,
              w: 80,
              h: 50,
              text_size: 46,
              char_space: 0,
              line_space: 0,
			  text: '40',
			  font: 'fonts/DirectoBold.ttf',
              color: 0xffffff,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
            });


	//----- Активность -----
/*
            actText = hmUI.createWidget(hmUI.widget.TEXT, {
              x: centerX + 5,
              y: centerY + 80,
              w: centerX - 35,
              h: 46,
              text_size: 30,
              char_space: 1,
              line_space: 0,
			  text: activities[actIndex][lang],
			  font: 'fonts/DirectoBold.ttf',
              color: colors[cIndex[0]],
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
            });
*/

			actIcon = hmUI.createWidget(hmUI.widget.IMG, {
              x: centerX - 80,
              y: DEVICE_HEIGHT - 76,
              w: 46,
              h: 46,
			  auto_scale: true,
			  src: `ico_${actIndex}.png`,
			});

            actValueText = new TextWithShadow({
              x: centerX - 55,
              y: DEVICE_HEIGHT - 78,
              w: 150,
              h: 44,
              text_size: 36,
              char_space: 0,
              line_space: 0,
			  text: getActivityValue(actIndex),
			  font: 'fonts/DirectoBold.ttf',
              color: 0xe5e5e5,
			  color_shadow: 0x404040,
			  offset: 2,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
            });

            hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: sc(160),
			  y: DEVICE_HEIGHT - 30,
			  w: DEVICE_WIDTH - 2 * sc(160),
			  h: 10,
              color: 0x000000,
			  alpha: 100,
			  radius: 3,
            });
/*
            hmUI.createWidget(hmUI.widget.STROKE_RECT, {
			  x: sc(160),
			  y: DEVICE_HEIGHT - 25,
			  w: DEVICE_WIDTH - 2 * sc(160),
			  h: 10,
              color: 0xdedede,
			  radius: 3,
			  line_width: 2
            });
*/
            actScale = hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: sc(160),
			  y: DEVICE_HEIGHT - 30,
			  w: 0,
			  h: 10,
              color: 0xdedede,
			  radius: 3,
            });



	//----- батарея -----

			hmUI.createWidget(hmUI.widget.IMG, {
              x: centerX - 47,
              y: sc(32),
              w: 26,
              h: 36,
			  src: 'ico_batt.png',
			});

            battText = new TextWithShadow({
              x: centerX - 19,
              y: sc(30),
              w: 110,
              h: 34,
              text_size: 30,
              char_space: 0,
              line_space: 0,
			  text: '84%',
			  font: 'fonts/DirectoBold.ttf',
              color: 0xf0f0f0,
			  color_shadow: 0x404040,
			  offset: 1,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
            });

            hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: sc(190),
			  y: sc(17),
			  w: DEVICE_WIDTH - 2 * sc(190),
			  h: 10,
              color: 0x000000,
			  alpha: 100,
			  radius: 3,
            });
/*
            hmUI.createWidget(hmUI.widget.STROKE_RECT, {
			  x: sc(190),
			  y: sc(17),
			  w: DEVICE_WIDTH - 2 * sc(190),
			  h: 10,
              color: 0xdedede,
			  radius: 3,
			  line_width: 2
            });
*/
            battScale = hmUI.createWidget(hmUI.widget.FILL_RECT, {
			  x: sc(190),
			  y: sc(17),
			  w: 0,
			  h: 10,
              color: 0xdedede,
			  radius: 3,
            });

			hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: centerX - 44,
              y: sc(31),
			  src: 'status_bt.png',
			  type: hmUI.system_status.DISCONNECT,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});

	// будильник
		// фоновый значок
			hmUI.createWidget(hmUI.widget.IMG, {
			  x: sc(17),
			  y: sc(178),
              w: 36,
              h: 34,
			  src: 'alarm_off.png',
			});

			hmUI.createWidget(hmUI.widget.IMG_STATUS, {
			  x: sc(17),
			  y: sc(178),
			  src: 'status_clock.png',
			  type: hmUI.system_status.CLOCK,
			  show_level: hmUI.show_level.ONLY_NORMAL,
			});
			
// БУДИЛЬНИК для превью
/*
            hmUI.createWidget(hmUI.widget.TEXT, {
				x: sc(3),
				y: sc(207),
				w: 60,
				h: 26,
				text_size: 20,
				color: 0xf0f0f0,
				font: 'fonts/DirectoBold.ttf',
				text: '07:20',
				padding: true,
				align_h: hmUI.align.CENTER_H,
				type: hmUI.data_type.ALARM_CLOCK,
				show_level: hmUI.show_level.ONLY_NORMAL,
            });
*/
            hmUI.createWidget(hmUI.widget.TEXT_FONT, {
				x: sc(3),
				y: sc(207),
				w: 60,
				h: 46,
				text_size: 20,
				color: 0xf0f0f0,
				font: 'fonts/DirectoBold.ttf',
				padding: true,
				invalid_visible: false,
				invalid_image: '***',
				align_h: hmUI.align.CENTER_H,
				type: hmUI.data_type.ALARM_CLOCK,
				show_level: hmUI.show_level.ONLY_NORMAL,
            });


//----- тап-зоны -----
		// будильник
            hmUI.createWidget(hmUI.widget.IMG_CLICK, {
				x: sc(3),
				y: sc(170),
				w: 60,
				h: 60,
				src: 'blank.png',
				type: hmUI.data_type.ALARM_CLOCK,
            });

		// календарь
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: sc(30),
              y: sc(242),
			  w: sc(70),
			  h: sc(80),
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				vibro();
				hmApp.startApp({ url: 'ScheduleCalScreen', native: true });
			  },
			});

		// погода приложение
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: sc(200),
              y: sc(85),
			  w: sc(220),
			  h: sc(140),
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				vibro();
				//launchApp({ url: 'WeatherScreen', native: true });
				setTimeout(() => {
					//launchApp({ appId: mini_app_id, url: 'page/index' });
					hmApp.startApp({ appid: mini_app_id, url: 'page/index' });
				}, 100);
			  },
			});

		// переключаем активности - нажатие
		// запуск приложения активности - долгое нажатие
			hmUI.createWidget(hmUI.widget.BUTTON, {
              x: centerX - 80,
              y: DEVICE_HEIGHT - 80,
			  w: 160,
			  h: 80,
			  text: '',
			  normal_src: 'blank.png',
			  press_src: 'blank.png',
			  click_func: () => {
				toggleActivity();
			  },
			  longpress_func: () => {
				  showActivityScreen();
			  },
			});


			curTime.addEventListener(curTime.event.MINUTEEND, function () {
				updateAllInfo();
			});

			step.addEventListener(hmSensor.event.CHANGE, function() {
				if (actIndex == 0) updateActivityInfo(0);
			});

            battery.addEventListener(hmSensor.event.CHANGE, function() {
				updateBattery();
            });

            heart.addEventListener(hmSensor.event.LAST, function() {
				if (actIndex == 2) updateActivityInfo(2);
            });

			const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
			  resume_call: (function () {
				//setActualTime();
				getLangIndex();
				//updateSunDataAndWeatherIcons();
				updateAllInfo();
				updateWeatherData();
				onDigitalCrown();
			  }),
			  pause_call: (function () {
				offDigitalCrown();
				//if (curAODmode > 2 && lastSelectedIndex != actIndex) hmFS.SysProSetInt('infoMAX_actIndex', actIndex);
			  }),
			})

            },
            onInit() {
            },
            build() {
                this.init_view();

            },
            onDestroy() {
				offDigitalCrown();
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
}